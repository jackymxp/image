package com.company;
import static com.company.SortHelper.swap;

public class SelectSort implements ISort {
    @Override
    public void sortAdvance(Comparable[] arr) {
        for(int i = 0; i < arr.length; i++){
            int minIndex = selectMinIndex(arr, i, arr.length-1);
            if(minIndex != i)
                swap(arr, minIndex, i);
        }
    }

    @Override
    public void sortIterative(Comparable[] arr) {
        for(int i = 0; i < arr.length; i++){
            int minIndex = selectMinIndex(arr, i, arr.length-1);
            swap(arr, minIndex, i);
        }
    }

    @Override
    public void sortRecursive(Comparable[] arr) {
        sortRecursive(arr, arr.length, 0);
    }
    private void sortRecursive(Comparable[] arr, int len, int index) {
        if(len == index)
            return ;
        int minIndex = selectMinIndexRecursive(arr, index, len-1);
        swap(arr, minIndex, index);
        sortRecursive(arr, len, index+1);
    }
    int selectMinIndex(Comparable[] arr, int startIndex, int endIndex)
    {
        int minIndex = startIndex;
        for(int i = startIndex+1; i <= endIndex; i++)
            minIndex = ((arr[i].compareTo(arr[minIndex]) < 0)) ? i : minIndex;
        return minIndex;
    }
    int selectMinIndexRecursive(Comparable[] arr, int startIndex, int endIndex)
    {
        if(startIndex == endIndex)
            return startIndex;
        int tmp = selectMinIndexRecursive(arr, startIndex+1, endIndex);
        return arr[startIndex].compareTo(arr[tmp]) < 0 ? startIndex : tmp;
    }
}
