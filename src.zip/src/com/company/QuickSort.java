package com.company;
import java.util.Random;

import static com.company.SortHelper.swap;

public class QuickSort implements ISort{
    //三路归并排序
    @Override
    public void sortAdvance(Comparable[] arr) {
        quickSort3Ways(arr, 0, arr.length-1);
    }

    @Override
    public void sortIterative(Comparable[] arr) {
        sortIterative(arr, 0, arr.length-1);
    }

    @Override
    public void sortRecursive(Comparable[] arr) {
        sortRecursive(arr, 0, arr.length-1);
    }

    void sortIterative(Comparable[] arr, int l, int h) {

        int stack[] = new int[h - l + 1];

        // initialize top of stack
        int top = -1;

        // push initial values in the stack
        stack[++top] = l;
        stack[++top] = h;

        // keep popping elements until stack is not empty
        while (top >= 0) {
            // pop h and l
            h = stack[top--];
            l = stack[top--];

            // set pivot element at it's proper position
            int p = partitionAdvance(arr, l, h);

            // If there are elements on left side of pivot,
            // then push left side to stack
            if (p - 1 > l) {
                stack[++top] = l;
                stack[++top] = p - 1;
            }

            // If there are elements on right side of pivot,
            // then push right side to stack
            if (p + 1 < h) {
                stack[++top] = p + 1;
                stack[++top] = h;
            }
        }
    }

    private void quickSort3Ways(Comparable[] arr, int start, int end){
        if(start >= end)
            return ;
        //v= arr[lt...gt]
        Comparable v = selectBase(arr, start, end);
        //(start lt)  < v    arr(gt...end] > v
        int lt = start, gt = end;
        int i = start+1;
        while(i <= gt){
            Comparable e = arr[i];
            if(e.compareTo(v) < 0){
                swap(arr, lt, i);
                lt++;
                i++;
            }
            else if(e.compareTo(v) == 0)
                i++;
            else{
                swap(arr, gt, i);
                gt--;
            }
        }
        quickSort3Ways(arr, start, lt-1);
        quickSort3Ways(arr, gt+1, end);

    }
    private int partition(Comparable[] arr, int start, int end){
        Comparable v = selectBase(arr, start, end);
        int i = start+1, j = start;
        while(i <= end) {
            if(arr[i].compareTo(v) < 0) {
                swap(arr, j + 1, i);
                j++;
            }
            i++;
            if(i > end)
                break;
        }
        swap(arr, start, j);
        return j;
    }
    //返回一个基准，并且将基准放在arr[start]位置
    private Comparable selectBase(Comparable[] arr, int start, int end){
        int index = (new Random()).nextInt(end-start+1)+start;
        swap(arr, start, index);
        return arr[start];
    }
    private int partitionAdvance(Comparable[] arr, int start, int end){
        Comparable v = selectBase(arr, start, end);
        int i = start+1, j = end;
        while(true){
            while(i <= end && arr[i].compareTo(v) <= 0)  i++;
            while (j >= start+1 && arr[j].compareTo(v) >= 0)   j--;
            if(i >= j)
                break;
            swap(arr, i, j);
        }
        swap(arr, start, j);
        return j;
    }
    private void sortRecursive(Comparable[] arr, int start, int end){
        if(start >= end)
            return ;
        int p = partition(arr, start, end);
        sortRecursive(arr, start, p-1);
        sortRecursive(arr, p+1, end);
    }
}
