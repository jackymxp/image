package com.company;
import static com.company.SortHelper.swap;


public class InsertSort implements ISort
{
    @Override
    public void sortIterative(Comparable[] arr) {
        for(int i = 1; i < arr.length; i++)
            insertOpeartor(arr, i);
    }

    @Override
    public void sortRecursive(Comparable[] arr) {
        sortRecursive(arr, arr.length);
    }

    @Override
    public void sortAdvance(Comparable[] arr) {
        for(int i = 1; i < arr.length; i++)
            insertOpeartorAdvance(arr, i);
    }

    private void sortRecursive(Comparable[] arr, int len){
        if(len == 1)    return;
        sortRecursive(arr, len - 1);
        insertOpeartorAdvance(arr, len - 1);
    }

    private void insertOpeartor(Comparable[] arr, int i){
        for(int j = i; j > 0 && arr[j].compareTo(arr[j-1]) < 0; j--)
            swap(arr, j, j-1);
    }

    private void insertOpeartorAdvance(Comparable[] arr, int i){
        Comparable last = arr[i];
        int j = i - 1;
        while(j>=0 && (last.compareTo(arr[j]) < 0)) {
            swap(arr, j, j+1);
            j--;
        }
        arr[j+1] = last;
    }
}