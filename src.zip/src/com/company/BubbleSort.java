package com.company;
import static com.company.SortHelper.swap;


public class BubbleSort implements ISort
{
    @Override
    public void sortIterative(Comparable[] arr) {
        for(int i = arr.length; i >= 0; i--)
            bubbleOpeartor(arr, i);
    }

    @Override
    public void sortRecursive(Comparable[] arr) {
        sortRecursive(arr, arr.length);
    }

    @Override
    public void sortAdvance(Comparable[] arr) {
        for(int i = arr.length; i >= 0; i--)
            if(bubbleOpeartorAdvance(arr, i) == true)
                return;
    }

    private void sortRecursive(Comparable[] arr, int len){
        if(len == 1)
            return;
        bubbleOpeartor(arr, len);
        sortRecursive(arr, len - 1);
    }
    //对于长度为len的数组，做冒泡过程，将最大值放在arr[len-1]位置
    private boolean bubbleOpeartorAdvance(Comparable[] arr, int len){
        boolean isSort = true;
        for(int i = 0; i < len - 1; i++)
            if((arr[i+1].compareTo(arr[i]) < 0)){
                swap(arr, i, i+1);
                isSort = false;
            }
        return isSort;
    }
    //对于长度为len的数组，做冒泡过程，将最大值放在arr[len-1]位置
    private void bubbleOpeartor(Comparable[] arr, int len){
        for(int i = 0; i < len - 1; i++)
            if((arr[i+1].compareTo(arr[i]) < 0))
                swap(arr, i, i+1);
    }
}