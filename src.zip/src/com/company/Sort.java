package com.company;

enum SORT_ALGORITHM{
    BUBBLE_SORT,
    SELECT_SORT,
    INSERT_SORT,
    SHELL_SORT,

    HEAP_SORT,
    QUICK_SORT,
    MERGE_SORT
}

public class Sort implements ISort{
    private ISort sort = null;
    private SORT_ALGORITHM sortAlgorithm = SORT_ALGORITHM.QUICK_SORT;

    public Sort(){
        setSortAlgorithm(sortAlgorithm);
    }
    public Sort(SORT_ALGORITHM sortAlgorithm){
        this.sortAlgorithm = sortAlgorithm;
        setSortAlgorithm(sortAlgorithm);
    }

    public void setSortAlgorithm(SORT_ALGORITHM sortAlgorithm){
        switch (sortAlgorithm){
            case BUBBLE_SORT:
                System.out.println("冒泡排序");
                this.sort = new BubbleSort();
                break;

            case INSERT_SORT:
                System.out.println("插入排序");
                this.sort = new InsertSort();
                break;

            case SELECT_SORT:
                System.out.println("选择排序");
                this.sort = new SelectSort();
                break;

            case SHELL_SORT:
                System.out.println("希尔排序");
                this.sort = new ShellSort();
                break;

            case QUICK_SORT:
                System.out.println("快速排序");
                this.sort = new QuickSort();
                break;

            case MERGE_SORT:
                System.out.println("归并排序");
                this.sort = new MergeSort();
                break;

            case HEAP_SORT:
                System.out.println("堆排序");
                this.sort = new HeapSort();
                break;

            default:
                throw new IllegalArgumentException("没有这个排序方案");
        }
    }

    @Override
    public void sortIterative(Comparable[] arr) {
        sort.sortIterative(arr);
    }

    @Override
    public void sortRecursive(Comparable[] arr) {
        sort.sortRecursive(arr);
    }

    @Override
    public void sortAdvance(Comparable[] arr) {
        sort.sortAdvance(arr);
    }
}
