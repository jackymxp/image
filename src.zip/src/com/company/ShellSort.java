package com.company;
import static com.company.SortHelper.swap;

public class ShellSort implements ISort {
    @Override
    public void sortIterative(Comparable[] arr) {
        int h = 1;
        int len = arr.length;
        while (h < len / 3)
            h = h + 3 + 1;
        while (h >= 1) {
            for (int i = h; i < len; i++) {
                for (int j = i; j >= h && arr[j].compareTo(arr[j - h]) < 0; j -= h)
                    swap(arr, j, j - h);
            }
            h /= 3;
        }
    }

    @Override
    public void sortRecursive(Comparable[] arr) {
        sortRecursive(arr, arr.length / 2);
    }

    @Override
    public void sortAdvance(Comparable[] arr) {
        int len = arr.length;
        // Start with a big gap, then reduce the gap
        for (int gap = len/2; gap > 0; gap /= 2)
        {
            // Do a gapped insertion sort for this gap size.
            // The first gap elements a[0..gap-1] are already
            // in gapped order keep adding one more element
            // until the entire array is gap sorted
            for (int i = gap; i < len; i += 1)
            {
                // add a[i] to the elements that have been gap
                // sorted save a[i] in temp and make a hole at
                // position i
                Comparable temp = arr[i];

                // shift earlier gap-sorted elements up until
                // the correct location for a[i] is found
                int j;
                for (j = i; j >= gap && arr[j - gap].compareTo(temp) > 0; j -= gap)
                    arr[j] = arr[j - gap];
                // put temp (the original a[i]) in its correct
                // location
                arr[j] = temp;
            }
        }
    }


    private void sortRecursive(Comparable[] arr, int step) {
        int len = arr.length;
        for (int i = 0; i < step; i++) {
            for (int j = i + step; j < len; j += step) {
                Comparable cur = arr[j];
                int k = j - step;
                while (k > -1) {
                    if (arr[k].compareTo(cur) > 0) {
                        arr[k + step] = arr[k];
                        k -= step;
                    }
                    else
                        break;
                }
                arr[k + step] = cur;
            }
        }
        if(step > 1)
            sortRecursive(arr, step / 2);
    }
}
