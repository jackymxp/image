package com.company;

import java.util.Random;

public class SortHelper {

    public static Comparable[] generateRandomArray(int num, int left, int right){
        Comparable[] arr = new Comparable[num];
        for(int i = 0; i < num; i++)
            arr[i] = (new Random()).nextInt(right-left+1)+left;
        return arr;
    }

    public static void testSortWay(String sortName, ISort sort, int num, int left, int right){

        Comparable[] arr1 = generateRandomArray(num, left, right);
        Comparable[] arr2 = cloneArray(arr1);
        Comparable[] arr3= cloneArray(arr1);

        long startTime1, startTime2, startTime3;
        long endTime1, endTime2, endTime3;

        System.out.println("**********" + sortName + "测试结果" + "*****************");

        startTime1 = System.nanoTime();
        sort.sortIterative(arr1);
        endTime1 = System.nanoTime();

        if(isSort(arr1) == false)
            System.out.println("############ 迭代方式测试失败 ############");
        else
            System.out.println("迭代运行时间： "+ (double)(endTime1-startTime1) / Math.pow(10, 6) +"ms");


        startTime2 = System.nanoTime(); //获取开始时间
        sort.sortRecursive(arr2);
        endTime2 = System.nanoTime(); //获取开始时间

        if(isSort(arr2) == false)
            System.out.println("############ 递归方式测试失败 ############");
        else
            System.out.println("递归运行时间： "+ (double)(endTime2-startTime2) / Math.pow(10, 6) +"ms");


        startTime3 = System.nanoTime(); //获取开始时间
        sort.sortAdvance(arr3);
        endTime3 = System.nanoTime(); //获取开始时间


        if(isSort(arr3) == false)
            System.out.println("############ 改进方式测试失败 ############");
        else
            System.out.println("改进运行时间： "+ (double)(endTime3-startTime3) / Math.pow(10, 6) +"ms");

        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");

    }

    public static Comparable[] cloneArray(Comparable[] src){
        int len = src.length;
        Comparable[] res = new Comparable[len];
        for(int i = 0; i < len; i++)
            res[i] = src[i];
        return res;
    }

    public static void swap(Comparable[] arr, int idxA, int idxB){
        Comparable tmp = arr[idxA];
        arr[idxA] = arr[idxB];
        arr[idxB] = tmp;
    }


    public static boolean isSort(Comparable[] arr){
        for(int i = 0; i < arr.length-1; i++)
            if(arr[i].compareTo(arr[i+1]) > 0)
                return false;
        return true;
    }
    public static void printArray(Comparable[] arr){
        for(int i = 0; i < arr.length; i++)
            System.out.print(arr[i] + "  ");
        System.out.println();
    }

}
