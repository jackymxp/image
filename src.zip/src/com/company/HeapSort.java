package com.company;

import static com.company.SortHelper.swap;

public class HeapSort implements ISort {
    @Override
    public void sortIterative(Comparable[] arr) {
        buildHeap(arr);
        for(int i = arr.length-1; i >= 0; i--) {
            swap(arr, 0, i);
            shiftDown(arr, 0, i);
        }
    }

    @Override
    public void sortRecursive(Comparable[] arr) {
        //DHeapSort(arr);
        buildHeapRecursion(arr);
        for(int i = arr.length-1; i >= 0; i--) {
            swap(arr, 0, i);
            shiftDownRecursion(arr, 0, i);
        }
    }

    //采用3叉堆实现
    @Override
    public void sortAdvance(Comparable[] arr) {
        buildHeapAdvance(arr);
        for(int i = arr.length-1; i >= 0; i--) {
            swap(arr, 0, i);
            shiftDownAdvance(arr, 0, i);
        }
    }

    //d叉堆，叉的个数
    private int dChild = 18;
    //第d个孩子的序号
    private int leftChildIndexDHeap(int parent){
        return  dChild * parent + 1;
    }


    public void DHeapSort(Comparable[] arr){
        buildDHeap(arr);
        for(int i = arr.length-1; i >= 0; i--) {
            swap(arr, 0, i);
            shiftDownDHeap(arr, 0, i);
        }
    }

    private void buildDHeap(Comparable[] arr){
        for(int i = (arr.length-1)/dChild; i >= 0; i--)
            shiftDownDHeap(arr, i, arr.length);
    }

    private void shiftDownDHeap(Comparable[] arr, int index, int len){
        int left = leftChildIndexDHeap(index);
        if(left >= len)
            return ;
        int right = left + dChild - 1;
        int maxIndex = index;
        for(int childIndex = left; childIndex < len && childIndex <= right; childIndex++)
        {
            if(arr[childIndex].compareTo(arr[maxIndex]) > 0)
                maxIndex = childIndex;
        }
        if(index != maxIndex){
            swap(arr, index, maxIndex);
            shiftDownDHeap(arr, maxIndex, len);
        }
    }

    private void buildHeapAdvance(Comparable[] arr){
        for(int i = (arr.length-1)/3; i >= 0; i--)
            shiftDownAdvance(arr, i, arr.length);
    }

    private void shiftDownAdvance(Comparable[] arr, int index, int len){
        //退出条件
        int left = 3 * index + 1;;
        if(left >= len)
            return ;
        int mid = left + 1;
        int right = left + 2;
        int maxIndex = index;
        if(left < len && arr[left].compareTo(arr[maxIndex]) > 0)
            maxIndex = left;
        if(mid < len && arr[mid].compareTo(arr[maxIndex]) > 0)
            maxIndex = mid;
        if(right < len && arr[right].compareTo(arr[maxIndex]) > 0)
            maxIndex = right;
        if(maxIndex != index){
            swap(arr, index, maxIndex);
            shiftDownAdvance(arr, maxIndex, len);
        }
    }
    private void buildHeap(Comparable[] arr){
        for(int i = arr.length/2-1; i >= 0; i--)
            shiftDown(arr, i, arr.length);
    }

    private void buildHeapRecursion(Comparable[] arr){
        for(int i = arr.length/2-1; i >= 0; i--)
            shiftDownRecursion(arr, i, arr.length);
    }

    private int leftChildIndex(int parent){return (parent << 1) + 1;}
    private void shiftDown(Comparable[] arr, int index, int len){
        while(leftChildIndex(index) < len){
            int left = leftChildIndex(index);
            int right = left + 1;
            int maxIndex = left;
            if(right < len && arr[right].compareTo(arr[maxIndex]) > 0)
                maxIndex = right;
            if(arr[maxIndex].compareTo(arr[index]) > 0)
                swap(arr, index, maxIndex);
            index = maxIndex;
        }
    }
    private void shiftDownRecursion(Comparable[] arr, int index, int len){
        if(leftChildIndex(index) >= len)
            return;
        int left = leftChildIndex(index);
        int right = left + 1;
        int maxIndex = index;
        if(left < len && arr[left].compareTo(arr[maxIndex]) > 0)
            maxIndex = left;
        if(right < len && arr[right].compareTo(arr[maxIndex]) > 0)
            maxIndex = right;
        if(maxIndex != index){
            swap(arr, index, maxIndex);
            shiftDownRecursion(arr, maxIndex, len);
        }
    }
}

