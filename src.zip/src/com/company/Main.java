package com.company;

import static com.company.SortHelper.*;


public class Main{

    public static void main(String args[]){

        int N = 100000;

        Comparable[] arr = generateRandomArray(N, 0, N);

        Sort sort = new Sort();

        for(SORT_ALGORITHM o : SORT_ALGORITHM.values()) {
            System.out.println(o);
            sort.setSortAlgorithm(o);
        }

        sort.sortIterative(arr);

        System.out.println(isSort(arr));

        //testSortWay("冒泡排序", new BubbleSort(), N, 0, N);
        //testSortWay("选择排序", new SelectSort(), N, 0, N);
        //testSortWay("插入排序", new InsertSort(), N, 0, N);
        //testSortWay("希尔排序", new ShellSort(), N, 0, N);


        //testSortWay("归并排序", new MergeSort(), N, 0, N);
        //testSortWay("堆排序", new HeapSort(), N, 0, N);
        //testSortWay("快速排序", new QuickSort(), N, 0, N);



    }
}