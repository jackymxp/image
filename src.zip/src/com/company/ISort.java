package com.company;

public interface ISort {
    default void swap(Comparable[] arr, int a, int b){
        Comparable t = arr[a];
        arr[a] = arr[b];
        arr[b] = t;
    }
    void sortIterative(Comparable[] arr);
    void sortRecursive(Comparable[] arr);
    void sortAdvance(Comparable[] arr);
}
