package com.company;

public class MergeSort implements ISort {

    @Override
    public void sortIterative(Comparable[] arr) {
        int len = arr.length;
        Comparable[] aux = new Comparable[len];
        for(int sz = 1; sz < len; sz = sz + sz){
            for(int lo = 0; lo < len - sz; lo += sz + sz){
                merge(arr, lo, lo+sz-1, Math.min(lo+sz+sz-1, len-1), aux);
            }
        }
    }

    @Override
    public void sortRecursive(Comparable[] arr) {
        Comparable[] aux = new Comparable[arr.length];
        sortRecursive(arr, 0, arr.length-1, aux);
    }

    @Override
    public void sortAdvance(Comparable[] arr) {
        Comparable[] aux = new Comparable[arr.length];
        mergeSort3Ways(arr, 0, arr.length-1, aux);
    }

    private void mergeSort3Ways(Comparable[] arr, int start, int end, Comparable[] aux){
        if(start >= end)
            return;
        int mid1 = ((end - start) / 3) + start;
        int mid2 = 2 * ((end - start) / 3) + start + 1;

        mergeSort3Ways(arr, start, mid1, aux);
        mergeSort3Ways(arr, mid1+1, mid2, aux);
        mergeSort3Ways(arr, mid2+1, end, aux);

        merge(arr, start, mid1, mid2, end, aux);
    }

    private void merge(Comparable[] arr, int start, int mid1, int mid2, int end, Comparable[] aux) {
        for(int i = start; i <= end; i++)
            aux[i] = arr[i];

        int i = start, j = mid1+1, k = mid2+1, l = start;
        while ((i <= mid1) && (j <= mid2) && (k <= end)) {
            if(aux[i].compareTo(aux[j]) < 0)
                arr[l++] = aux[i].compareTo(aux[k]) < 0 ? aux[i++] : aux[k++];
            else
                arr[l++] = aux[j].compareTo(aux[k]) < 0 ? aux[j++] : aux[k++];
        }
        while ((i <= mid1) && (j <= mid2))
            arr[l++] = aux[i].compareTo(aux[j]) < 0 ? aux[i++] : aux[j++];
        while ((i <= mid1) && (k <= end))
            arr[l++] = aux[i].compareTo(aux[k]) < 0 ? aux[i++] : aux[k++];
        while ((k <= end) && (j <= mid2))
            arr[l++] = aux[k].compareTo(aux[j]) < 0 ? aux[k++] : aux[j++];

        while(i <= mid1)
            arr[l++] = aux[i++];
        while(j <= mid2)
            arr[l++] = aux[j++];
        while(k <= end)
            arr[l++] = aux[k++];
    }

    private void sortRecursive(Comparable[] arr, int left, int right, Comparable[] aux){
        if(left >= right)
            return ;
        int mid = (right - left) / 2 + left;
        sortRecursive(arr, left, mid, aux);
        sortRecursive(arr, mid+1, right, aux);
        merge(arr, left, mid, right, aux);
    }

    private void merge(Comparable[] arr, int start, int mid, int end, Comparable[] aux)
    {
        for(int i = start; i <= end; i++)
            aux[i] = arr[i];
        int i = start, j = mid+1;
        for(int k = start; k <= end; k++){
            if(i > mid)                                 arr[k] = aux[j++];
            else if(j > end)                            arr[k] = aux[i++];
            else if(aux[i].compareTo(arr[j]) < 0)       arr[k] = aux[i++];
            else                                        arr[k] = aux[j++];
        }
    }
}
