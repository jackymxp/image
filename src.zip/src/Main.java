import java.util.*;

class A{
    public String s;
    public A(String s){
        System.out.println(s);
        this.s = s;
    }
    public static void main(String[] args){
        final int x = 1;
        //x = 2;

        final A a = new A("a");
        a.s = "abc";
        //a = new A("b");
    }
}

class OrderInit{
    //静态语句块
    static{
        A a2 = new A("父类中静态语句块");
    }
    //普通变量
    A a3 = new A("父类中的实例变量");
    //普通语句块
    {
        A a4 = new A("父类中的普通语句块");
    }
    //静态变量
    static A a1 = new A("父类中的静态变量");

    public OrderInit(){
        System.out.println("父类 构造函数");
    }
}

class OrderInitChild extends OrderInit{
    //静态语句块
    static{
        A a5 = new A("子类中静态语句块");
    }
    //普通变量
    A a6= new A("子类中的实例变量");
    //普通语句块
    {
        A a7 = new A("子类中的普通语句块");
    }
    //静态变量
    static A a8 = new A("子类中的静态变量");

    public OrderInitChild(){
        System.out.println("子类 构造函数");
    }
}


interface TestInterface{
    public int a = 0;
    int b = 0;
}



class Parent{
    private int x;
    Parent(int x){
        System.out.println("我是父类");
        this.x = x;
    }
    void ParentMethod(){
        System.out.println("ParentMethod");
    }
}

class Child extends Parent{
    private int y;
    Child(int x, int y){
        super(x);
        this.y = y;
    }

    @Override
    void ParentMethod() {
        super.ParentMethod();
        System.out.println("ChildMethod");
    }
}





class TestStaticBlock{
    static {
        System.out.println("TestStaticBlock");
    }
    public static void main(String[] args){
        TestStaticBlock testStaticBlock1 = new TestStaticBlock();
        TestStaticBlock testStaticBlock2 = new TestStaticBlock();
    }
}



class TestStaticVar{
    public static int staticVar = 0;
    public TestStaticVar(){
        staticVar++;
    }
    public static void main(String[] args){
        TestStaticVar testStaticVar1 = new TestStaticVar();
        //通过实例访问
        System.out.println(testStaticVar1.staticVar); //输出1
        //通过类访问
        System.out.println(TestStaticVar.staticVar);  //输出1

        TestStaticVar testStaticVar2 = new TestStaticVar();
        System.out.println(testStaticVar1.staticVar);  //输出2
        System.out.println(TestStaticVar.staticVar);  //输出2
    }
}

class OuterClass {
    class InnerClass {
    }

    static class StaticInnerClass {
    }
    public static void main(String[] args) {
        // InnerClass innerClass = new InnerClass(); // 'OuterClass.this' cannot be referenced from a static context
        OuterClass outerClass = new OuterClass();
        InnerClass innerClass = outerClass.new InnerClass();
        StaticInnerClass staticInnerClass = new StaticInnerClass();
    }
}



class TestThisAsConstructor {
    int Count = 0;
    String s = "initial value";

    TestThisAsConstructor(int petals) {
        Count = petals;
        System.out.println("Constructor w/ int arg only, petalCount = " + Count);
    }

    TestThisAsConstructor(String ss) {
        System.out.println("Constructor w/ string arg only, s = " + ss);
        s = ss;
    }

    TestThisAsConstructor(String s, int petals) {
        this(petals);
        //- this(s); // Can't call two!
        this.s = s; // Another use of "this"
        System.out.println("String & int args");
    }

    TestThisAsConstructor() {
        this("hi", 47);
        System.out.println("no-arg constructor");
    }

    void print() {
        //- this(11); // Not inside constructor!
        System.out.println("Count = " + Count + " s = " + s);
    }

    public static void main(String[] args) {
        TestThisAsConstructor x = new TestThisAsConstructor();
        x.print();
    }
}



class MyThread1 extends Thread{
    @Override
    public void run() {
        //super.run();
        System.out.println("MyThread1");
    }

    public static void main(String[] args){
        Thread thread1 = new MyThread1();
        thread1.start();
        System.out.println("MainThread");
    }
}


class MyRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("MyRunnable");
    }

    public static void main(String[] args) {
        MyRunnable instance = new MyRunnable();
        Thread thread = new Thread(instance);
        thread.start();
        System.out.println("MainThread");
    }
}







public class Main {

    public static void displayObjectClass(Object o) {
        if (o instanceof Character)
            System.out.println("对象是 Character 类的实例");
        else if (o instanceof Integer)
            System.out.println("对象是 Integer 类的实例");
        else
            System.out.println("对象是 " + o.getClass() + " 类的实例");

    }

    public static void main(String[] args){
        displayObjectClass(new Integer(3));

        int[] a = new int[100];
        Arrays.fill(a, 1);

        List<Integer> list = new ArrayList<>();
        List<Integer> list2 = new LinkedList<>();
    }
}
